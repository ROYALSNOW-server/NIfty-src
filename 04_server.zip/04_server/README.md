# NiftyServer — community server base

A minimal but **working and extensible** authoritative-server base for Nifty
Island v2.15.04. It speaks the game's real transport, frames/parses messages
correctly, resolves all 988 message types to human-readable names, and is
designed to be extended by dropping in handler classes.

It is the foundation for Phases 7–9. It is **not** yet a server the retail client
fully loads into — that needs the join-handshake capture (see "The one gap").

## Status — what works today ✅
- **Wire-compatible transport** — the game's own LiteNetLib (ProtocolId 11),
  engine-free. UDP connection handshake matches the client.
- **Correct framing** — `Protocol/NiftyWire.cs`: little-endian, `ushort MessageId
  @0`, `0xFFFF`-null length-prefixed UTF-8 strings, quantization helpers, and the
  exact `StableHash16` (FNV-32) id hash.
- **Full message catalogue** — all **988** message types embedded and resolved to
  ids, so logs read `AvatarTransformState` not `0x1A2B`. 5 hash-colliding ids are
  flagged AMBIGUOUS (confirm those against a capture).
- **Pluggable architecture** — `IMessageHandler` auto-registered by reflection;
  `ClientSession` per player; `ServerConfig` for settings; tick loop; broadcast
  helpers.
- **Proven end-to-end** by `--selftest` (loopback connect + round-trip). `PASS`.

## Build & run  (needs .NET 10 SDK — already installed)
```powershell
cd "04_server"
dotnet build NiftyServer.sln -c Release

dotnet run --project NiftyServer -- -p 3500          # run server on UDP 3500
dotnet run --project NiftyServer -- --selftest       # loopback proof
dotnet run --project NiftyServer -- --catalogue      # dump message_catalogue.md
```
Server args: `-p <port>`, `--tick <ms>`, `--quiet` (less logging).

## How to extend it  ← the point of this base
**Add a message handler** — create a file, rebuild, done (auto-registered):
```csharp
using NiftyServer.Protocol;
using NiftyServer.Server;

public sealed class AvatarMoveHandler : IMessageHandler
{
    public ushort MessageId => NiftyWire.StableHash16("AvatarTransformState");

    public void Handle(ClientSession session, byte[] payload, GameServer server)
    {
        // parse fields with NiftyWire.GetFloat/GetQuantizedFloat/... at their offsets
        // then e.g. relay to everyone else:
        server.BroadcastState(payload, except: session);
    }
}
```
- **Per-player state:** extend `ClientSession` (or use its `State` bag).
- **Handshake / on-connect logic:** set `GameServer.OnClientConnected`, or edit
  the `TODO(handshake)` in `GameServer.OnPeerConnected`.
- **Tick logic:** set `GameServer.OnTick` (fires every `TickRateMs`).
- **Settings:** edit `ServerConfig`.
- **Find a message's id/name:** `MessageCatalogue.Default.IdOf("...")` /
  `.Describe(id)`; full table in `05_research_notes/message_catalogue.md`.

## Project layout
```
NiftyServer/
├── Program.cs                 entry point (-p, --tick, --quiet, --selftest, --catalogue)
├── Protocol/
│   ├── NiftyWire.cs           wire framing + StableHash16 (engine-free)
│   ├── Messages.cs            Channels + GameSessionCommand (worked example)
│   ├── MessageCatalogue.cs    988 names -> ids, name resolution, collision report
│   ├── message_types.txt      embedded catalogue source (988 names)
│   ├── ByteBufferStub.cs      tiny stand-in so vendored LiteNetLib compiles
│   └── AppStubs.cs            App.Logging.Logger stand-in
├── Server/
│   ├── GameServer.cs          transport + dispatch + tick + broadcast
│   ├── ServerConfig.cs        settings
│   ├── ClientSession.cs       per-player state + senders
│   ├── IMessageHandler.cs     the extension interface
│   ├── MessageRouter.cs       id -> handler, auto-discovery
│   ├── Handlers/
│   │   └── GameSessionCommandHandler.cs   reference handler (copy this)
│   └── SelfTest.cs            loopback proof
└── LiteNetLib/                the game's own LiteNetLib (ProtocolId 11), engine-free
```

## The one gap (honest status)
The **application-level join handshake** is still stubbed. The client tells us
message shapes, not the server's opening sequence (which snapshot/commands it
sends on connect, what the client must receive to spawn). That comes from a
**live packet capture** — see `../06_capture/` (do it before the servers go down).
Hook points are marked `TODO(handshake)`.

To point the retail client here, use its **direct-IP connect** (host+port,
default 3500) to bypass the AWS matchmaker — see `../03_docs/04_WIRE_PROTOCOL.md`.

## Next steps
1. Run the capture (`06_capture/`), give the files to Claude.
2. Implement the handshake at the `TODO(handshake)` points.
3. Add handlers for the messages the handshake needs (each like the reference).
4. Grow `OnTick` into real world/state replication.

> ⚖️ Built for preservation/interoperability. Reproduce protocols and write your
> own logic; don't republish the game's proprietary code.
