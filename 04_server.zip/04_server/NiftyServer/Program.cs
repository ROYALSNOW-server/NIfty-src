using System;
using System.IO;
using NiftyServer.Protocol;
using NiftyServer.Server;

namespace NiftyServer
{
    internal static class Program
    {
        private static int Main(string[] args)
        {
            if (Array.IndexOf(args, "--selftest") >= 0)
                return SelfTest.Run();

            if (Array.IndexOf(args, "--catalogue") >= 0)
                return DumpCatalogue(args);

            if (Array.IndexOf(args, "--dumpids") >= 0)
            {
                var cat = MessageCatalogue.Default;
                var sb = new System.Text.StringBuilder();
                foreach (var name in cat.Names) sb.AppendLine($"{cat.IdOf(name)},{name}");
                string p = "ids.csv";
                for (int i = 0; i < args.Length - 1; i++) if (args[i] == "-o") p = args[i + 1];
                File.WriteAllText(p, sb.ToString());
                Console.WriteLine($"[dumpids] {cat.Count} id,name pairs -> {Path.GetFullPath(p)}");
                return 0;
            }

            var config = new ServerConfig();
            for (int i = 0; i < args.Length - 1; i++)
            {
                if (args[i] == "-p" && int.TryParse(args[i + 1], out int p)) config.Port = p;
                if (args[i] == "--tick" && double.TryParse(args[i + 1], out double t)) config.TickRateMs = t;
            }
            if (Array.IndexOf(args, "--quiet") >= 0) config.VerboseMessageLog = false;

            Console.WriteLine("=== Nifty Island community server (base) ===");
            var server = new GameServer(config);
            Console.CancelKeyPress += (_, e) => { e.Cancel = true; server.Stop(); };
            server.Run();
            Console.WriteLine("[server] stopped.");
            return 0;
        }

        private static int DumpCatalogue(string[] args)
        {
            var cat = MessageCatalogue.Default;
            string outPath = Path.GetFullPath("message_catalogue.md");
            for (int i = 0; i < args.Length - 1; i++)
                if (args[i] == "-o") outPath = Path.GetFullPath(args[i + 1]);

            cat.WriteMarkdown(outPath);
            int collisions = 0; foreach (var _ in cat.Collisions()) collisions++;
            Console.WriteLine($"[catalogue] {cat.Count} message types written to {outPath}");
            Console.WriteLine($"[catalogue] {collisions} hash-colliding id(s) flagged AMBIGUOUS.");
            Console.WriteLine($"[catalogue] example: GameSessionCommand = 0x{cat.IdOf("GameSessionCommand"):X4}");
            return 0;
        }
    }
}
