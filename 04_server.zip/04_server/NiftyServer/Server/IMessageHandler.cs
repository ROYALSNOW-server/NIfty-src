namespace NiftyServer.Server
{
    /// <summary>
    /// Implement this to handle one message type, then it is auto-registered at
    /// startup (the router reflects over the assembly for IMessageHandler types
    /// with a public parameterless constructor).
    ///
    /// Example:
    ///   public sealed class MyMoveHandler : IMessageHandler
    ///   {
    ///       public ushort MessageId => NiftyWire.StableHash16("AvatarTransformState");
    ///       public void Handle(ClientSession s, byte[] payload, GameServer server) { ... }
    ///   }
    ///
    /// That's the whole extension model — drop in a file, rebuild, done.
    /// </summary>
    public interface IMessageHandler
    {
        /// <summary>The MessageId (first ushort of every payload) this handler consumes.</summary>
        ushort MessageId { get; }

        /// <summary>Handle a decoded message from a client.</summary>
        void Handle(ClientSession session, byte[] payload, GameServer server);
    }
}
