using NiftyServer.Protocol;

namespace NiftyServer.Server
{
    /// <summary>Tweakable server settings. Edit here or override from Program args.</summary>
    public sealed class ServerConfig
    {
        /// <summary>UDP port to listen on. Client default direct-connect port is 3500.</summary>
        public int Port = NiftyWire.DefaultPort;

        /// <summary>Fixed simulation tick, milliseconds. From GameSimulationConfig the game runs a tick loop.</summary>
        public double TickRateMs = 50.0;

        /// <summary>Max players per island instance (game default is 20).</summary>
        public int MaxPlayers = 20;

        /// <summary>LiteNetLib connect key. The retail client's key is TBD from capture; Accept() ignores it.</summary>
        public string ConnectKey = "";

        /// <summary>Log every received message (with resolved name). Great while reverse-engineering a capture.</summary>
        public bool VerboseMessageLog = true;
    }
}
