using System;
using NiftyServer.Protocol;

namespace NiftyServer.Server.Handlers
{
    /// <summary>
    /// Reference handler — copy this shape for the other 987 message types.
    /// Auto-registered by MessageRouter.RegisterFromAssembly at startup.
    /// </summary>
    public sealed class GameSessionCommandHandler : IMessageHandler
    {
        public ushort MessageId => GameSessionCommand.MessageId;

        public void Handle(ClientSession session, byte[] payload, GameServer server)
        {
            string sessionId = GameSessionCommand.ReadId(payload);
            Console.WriteLine($"[handler] peer {session.Id} GameSessionCommand Id='{sessionId}'");

            session.SessionId = sessionId;
            // TODO(handshake): validate the session/auth token here, mark the player
            //   authenticated, and reply with the world snapshot the client needs.
            // session.Authenticated = true;
        }
    }
}
