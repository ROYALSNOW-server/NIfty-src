using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Threading;
using LiteNetLib;
using NiftyServer.Protocol;

namespace NiftyServer.Server
{
    /// <summary>
    /// Extensible authoritative game-server base for Nifty Island.
    ///
    /// Wire-compatible today: LiteNetLib (ProtocolId 11) transport, the ByteBuffer
    /// message envelope, StableHash16 ids, channel/delivery mapping. Proven by
    /// SelfTest (loopback connect + message round-trip).
    ///
    /// Extend it by dropping in an <see cref="IMessageHandler"/> — it auto-registers.
    /// The one missing piece for the retail client to fully load in is the
    /// application join handshake (marked TODO(handshake)); fill it from a capture.
    /// </summary>
    public sealed class GameServer : INetEventListener
    {
        public ServerConfig Config { get; }
        public MessageCatalogue Catalogue { get; } = MessageCatalogue.Default;
        public MessageRouter Router { get; } = new();

        /// <summary>Hook: runs when a peer connects (after a ClientSession is created). Put handshake here.</summary>
        public Action<ClientSession> OnClientConnected;
        /// <summary>Hook: runs each simulation tick.</summary>
        public Action<GameServer, long> OnTick;
        /// <summary>Hook: runs when a peer disconnects.</summary>
        public Action<ClientSession> OnClientDisconnected;

        private readonly NetManager _net;
        private readonly ConcurrentDictionary<int, ClientSession> _sessions = new();
        private volatile bool _running;

        public ICollection<ClientSession> Sessions => _sessions.Values;

        public GameServer(ServerConfig config = null)
        {
            Config = config ?? new ServerConfig();
            _net = new NetManager(this)
            {
                AutoRecycle = true,
                UnconnectedMessagesEnabled = false,
                ChannelsCount = 4, // client uses ch0 State, ch1 Command, ch2 Admin
            };
            Router.RegisterFromAssembly(Assembly.GetExecutingAssembly());
        }

        // convenience ctor kept for existing callers/tests
        public GameServer(int port, double tickRateMs = 50.0)
            : this(new ServerConfig { Port = port, TickRateMs = tickRateMs }) { }

        public void Run()
        {
            if (!_net.Start(Config.Port))
            {
                Console.WriteLine($"[server] FAILED to bind UDP :{Config.Port}");
                return;
            }
            _running = true;
            Console.WriteLine($"[server] listening udp :{Config.Port}  (LiteNetLib ProtocolId=11, tick={Config.TickRateMs}ms)");
            Console.WriteLine($"[server] {Catalogue.Count} known message types loaded; {Router.Handlers.Count} handler(s) registered.");
            Console.WriteLine($"[server] point the client here via direct-IP connect (host=127.0.0.1 port={Config.Port}).");

            long tick = 0;
            int sleep = (int)Math.Max(1, Config.TickRateMs);
            while (_running)
            {
                _net.PollEvents();
                OnTick?.Invoke(this, tick++);
                Thread.Sleep(sleep);
            }
            _net.Stop();
        }

        public void Stop() => _running = false;

        // ---- INetEventListener ------------------------------------------------
        public void OnConnectionRequest(ConnectionRequest request)
        {
            // Local transport accepts unconditionally. If a capture shows the real
            // server needs a connect key, switch to request.AcceptIfKey(Config.ConnectKey).
            NetPeer peer = request.Accept();
            Console.WriteLine($"[server] connect from {request.RemoteEndPoint} -> accepted (peer {peer?.Id})");
        }

        public void OnPeerConnected(NetPeer peer)
        {
            var session = new ClientSession(peer);
            _sessions[peer.Id] = session;
            Console.WriteLine($"[server] peer {peer.Id} connected");

            // TODO(handshake): send the initial world/session snapshot the client
            //   expects to spawn a player. Until captured, custom logic can hook
            //   OnClientConnected. Placeholder so a loopback client sees traffic:
            if (OnClientConnected != null) OnClientConnected(session);
            else session.SendCommand(GameSessionCommand.Create("server-hello"));
        }

        public void OnPeerDisconnected(NetPeer peer, DisconnectInfo disconnectInfo)
        {
            if (_sessions.TryRemove(peer.Id, out var session))
            {
                Console.WriteLine($"[server] peer {peer.Id} disconnected: {disconnectInfo.Reason}");
                OnClientDisconnected?.Invoke(session);
            }
        }

        public void OnNetworkReceive(NetPeer peer, NetPacketReader reader, DeliveryMethod deliveryMethod)
        {
            byte[] payload = reader.GetRemainingBytes(); // copy; AutoRecycle frees the reader
            if (payload.Length < 2) return;
            if (!_sessions.TryGetValue(peer.Id, out var session)) return;

            ushort id = NiftyWire.MessageId(payload);
            bool handled = Router.TryDispatch(session, id, payload, this);

            if (Config.VerboseMessageLog || !handled)
            {
                string name = Catalogue.Describe(id);
                string tag = handled ? "" : " [no handler]";
                Console.WriteLine($"[recv] peer {peer.Id} {deliveryMethod} {name} ({payload.Length}B){tag}");
            }
        }

        public void OnNetworkReceiveUnconnected(IPEndPoint remoteEndPoint, NetPacketReader reader, UnconnectedMessageType messageType) { }
        public void OnNetworkError(IPEndPoint endPoint, SocketError socketError) =>
            Console.WriteLine($"[server] net error {endPoint}: {socketError}");
        public void OnNetworkLatencyUpdate(NetPeer peer, int latency) { }

        // ---- broadcast helpers ------------------------------------------------
        public void Broadcast(byte[] msg, byte channel, DeliveryMethod delivery, ClientSession except = null)
        {
            foreach (var s in _sessions.Values)
                if (s != except) s.Peer.Send(msg, 0, msg.Length, channel, delivery);
        }

        public void BroadcastCommand(byte[] msg, ClientSession except = null) =>
            Broadcast(msg, Channels.Command, DeliveryMethod.ReliableOrdered, except);

        public void BroadcastState(byte[] msg, ClientSession except = null) =>
            Broadcast(msg, Channels.State, DeliveryMethod.Unreliable, except);
    }
}
