using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace NiftyServer.Server
{
    /// <summary>Maps MessageId -> handler and dispatches. Auto-discovers handlers.</summary>
    public sealed class MessageRouter
    {
        private readonly Dictionary<ushort, IMessageHandler> _handlers = new();

        public IReadOnlyDictionary<ushort, IMessageHandler> Handlers => _handlers;

        public void Register(IMessageHandler handler)
        {
            _handlers[handler.MessageId] = handler; // last registration wins
        }

        /// <summary>Find every IMessageHandler in the assembly and register it. Returns count.</summary>
        public int RegisterFromAssembly(Assembly asm)
        {
            int n = 0;
            foreach (Type t in asm.GetTypes())
            {
                if (t.IsAbstract || t.IsInterface) continue;
                if (!typeof(IMessageHandler).IsAssignableFrom(t)) continue;
                if (t.GetConstructor(Type.EmptyTypes) == null) continue;
                Register((IMessageHandler)Activator.CreateInstance(t));
                n++;
            }
            return n;
        }

        /// <summary>Dispatch. Returns false if no handler is registered for the id.</summary>
        public bool TryDispatch(ClientSession session, ushort id, byte[] payload, GameServer server)
        {
            if (_handlers.TryGetValue(id, out var handler))
            {
                handler.Handle(session, payload, server);
                return true;
            }
            return false;
        }
    }
}
