using System.Collections.Generic;
using LiteNetLib;
using NiftyServer.Protocol;

namespace NiftyServer.Server
{
    /// <summary>
    /// One connected player. Extend this with whatever per-player state your
    /// server needs (position, inventory, island id, etc.).
    /// </summary>
    public sealed class ClientSession
    {
        public ClientSession(NetPeer peer) { Peer = peer; }

        public NetPeer Peer { get; }
        public int Id => Peer.Id;

        /// <summary>Set true once you accept the player's auth/session token (see handshake TODO).</summary>
        public bool Authenticated;

        /// <summary>Session id carried in GameSessionCommand, once known.</summary>
        public string SessionId;

        public string PlayerName;

        /// <summary>Freeform bag so extensions can stash state without changing this class.</summary>
        public readonly Dictionary<string, object> State = new();

        // convenience senders (stock LiteNetLib path = wire-identical to client)
        public void SendCommand(byte[] msg) =>
            Peer.Send(msg, 0, msg.Length, Channels.Command, DeliveryMethod.ReliableOrdered);

        public void SendState(byte[] msg) =>
            Peer.Send(msg, 0, msg.Length, Channels.State, DeliveryMethod.Unreliable);
    }
}
