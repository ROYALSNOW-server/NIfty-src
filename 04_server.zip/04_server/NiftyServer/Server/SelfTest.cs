using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using LiteNetLib;
using NiftyServer.Protocol;

namespace NiftyServer.Server
{
    /// <summary>
    /// Loopback proof: a LiteNetLib client (same vendored lib, ProtocolId 11)
    /// connects to the GameServer, exchanges a GameSessionCommand both ways, and
    /// verifies the transport handshake + envelope framing + dispatch round-trip.
    /// Run with:  NiftyServer --selftest
    /// </summary>
    public sealed class SelfTest : INetEventListener
    {
        private const string ConnectKey = "nifty";
        private volatile bool _gotServerHello;
        private volatile string _serverHelloId;

        public static int Run()
        {
            int port = 34500; // isolated port for the test
            var server = new GameServer(port, tickRateMs: 20);
            var serverThread = new Thread(server.Run) { IsBackground = true };
            serverThread.Start();
            Thread.Sleep(300);

            var test = new SelfTest();
            var client = new NetManager(test) { AutoRecycle = true, ChannelsCount = 4 };
            client.Start();
            client.Connect("127.0.0.1", port, ConnectKey);

            var sw = System.Diagnostics.Stopwatch.StartNew();
            bool sent = false;
            NetPeer serverPeer = null;
            while (sw.ElapsedMilliseconds < 3000)
            {
                client.PollEvents();
                if (!sent && test._connectedPeer != null)
                {
                    serverPeer = test._connectedPeer;
                    byte[] msg = GameSessionCommand.Create("hello-from-client");
                    serverPeer.Send(msg, 0, msg.Length, Channels.Command, DeliveryMethod.ReliableOrdered);
                    Console.WriteLine("[selftest] client -> GameSessionCommand('hello-from-client')");
                    sent = true;
                }
                if (test._gotServerHello) break;
                Thread.Sleep(15);
            }

            client.Stop();
            server.Stop();

            bool ok = test._gotServerHello && test._serverHelloId == "server-hello";
            Console.WriteLine(ok
                ? $"[selftest] PASS — round-trip ok (server-hello id='{test._serverHelloId}')"
                : "[selftest] FAIL — did not complete round-trip");
            return ok ? 0 : 1;
        }

        private NetPeer _connectedPeer;

        // ---- INetEventListener (client side) ---------------------------------
        public void OnPeerConnected(NetPeer peer)
        {
            _connectedPeer = peer;
            Console.WriteLine($"[selftest] client connected to server (peer {peer.Id})");
        }

        public void OnNetworkReceive(NetPeer peer, NetPacketReader reader, DeliveryMethod deliveryMethod)
        {
            byte[] payload = reader.GetRemainingBytes();
            if (payload.Length >= 2 && NiftyWire.MessageId(payload) == GameSessionCommand.MessageId)
            {
                _serverHelloId = GameSessionCommand.ReadId(payload);
                _gotServerHello = true;
                Console.WriteLine($"[selftest] client <- GameSessionCommand('{_serverHelloId}')");
            }
        }

        public void OnPeerDisconnected(NetPeer peer, DisconnectInfo disconnectInfo) { }
        public void OnNetworkError(IPEndPoint endPoint, SocketError socketError) { }
        public void OnNetworkReceiveUnconnected(IPEndPoint remoteEndPoint, NetPacketReader reader, UnconnectedMessageType messageType) { }
        public void OnNetworkLatencyUpdate(NetPeer peer, int latency) { }
        public void OnConnectionRequest(ConnectionRequest request) => request.Reject();
    }
}
