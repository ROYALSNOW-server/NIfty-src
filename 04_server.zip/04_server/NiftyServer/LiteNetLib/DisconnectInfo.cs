using System.Net.Sockets;

namespace LiteNetLib;

public struct DisconnectInfo
{
	internal DisconnectReason Reason;

	public SocketError SocketErrorCode;

	public NetPacketReader AdditionalData;
}
