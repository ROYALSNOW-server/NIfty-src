using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using App.Logging;
using LiteNetLib.Utils;
using Transport.Common;


namespace LiteNetLib;

public class NetPeer
{
	private class IncomingFragments
	{
		public NetPacket[] Fragments;

		public int ReceivedCount;

		public int TotalSize;

		public byte ChannelId;
	}

	private int _rtt;

	private int _avgRtt;

	private int _rttCount;

	private double _resendDelay = 27.0;

	private int _pingSendTimer;

	private int _rttResetTimer;

	private readonly Stopwatch _pingTimer = new Stopwatch();

	private int _timeSinceLastPacket;

	private long _remoteDelta;

	private readonly NetPacketPool _packetPool;

	private readonly object _shutdownLock = new object();

	internal volatile NetPeer NextPeer;

	internal NetPeer PrevPeer;

	private readonly Queue<NetPacket> _unreliableChannel;

	private readonly Queue<BaseChannel> _channelSendQueue;

	private readonly BaseChannel[] _channels;

	private int _mtu;

	private int _mtuIdx;

	private bool _finishMtu;

	private int _mtuCheckTimer;

	private int _mtuCheckAttempts;

	private const int MtuCheckDelay = 1000;

	private const int MaxMtuCheckAttempts = 4;

	private readonly object _mtuMutex = new object();

	private int _fragmentId;

	private readonly Dictionary<ushort, IncomingFragments> _holdedFragments;

	private readonly Dictionary<ushort, ushort> _deliveredFragments;

	private readonly NetPacket _mergeData;

	private int _mergePos;

	private int _mergeCount;

	private int _connectAttempts;

	private int _connectTimer;

	private long _connectTime;

	private byte _connectNum;

	private ConnectionState _connectionState;

	private NetPacket _shutdownPacket;

	private const int ShutdownDelay = 300;

	private int _shutdownTimer;

	private readonly NetPacket _pingPacket;

	private readonly NetPacket _pongPacket;

	private readonly NetPacket _connectRequestPacket;

	private readonly NetPacket _connectAcceptPacket;

	private readonly int _reliableBytesPerUpdate;

	private int _reliableBytesSinceLastUpdate;

	private readonly Queue<(ByteBuffer data, byte channelNumber)> _bandwidthDelayedMessages = new Queue<(ByteBuffer, byte)>();

	private int _amountOfDelayedBytes;

	public readonly IPEndPoint EndPoint;

	public readonly NetManager NetManager;

	public readonly int Id;

	public object Tag;

	public readonly NetStatistics Statistics;

	internal byte ConnectionNum
	{
		get
		{
			return _connectNum;
		}
		private set
		{
			_connectNum = value;
			_mergeData.ConnectionNumber = value;
			_pingPacket.ConnectionNumber = value;
			_pongPacket.ConnectionNumber = value;
		}
	}

	public ConnectionState ConnectionState => _connectionState;

	internal long ConnectTime => _connectTime;

	public int Ping => _avgRtt / 2;

	public int Mtu => _mtu;

	public long RemoteTimeDelta => _remoteDelta;

	public DateTime RemoteUtcTime => new DateTime(DateTime.UtcNow.Ticks + _remoteDelta);

	public int TimeSinceLastPacket => _timeSinceLastPacket;

	internal double ResendDelay => _resendDelay;

	internal NetPeer(NetManager netManager, IPEndPoint remoteEndPoint, int id)
	{
		float num = 1000f / (float)netManager.UpdateTime;
		float num2 = 250000f;
		_reliableBytesPerUpdate = (int)System.Math.Floor((double)(num2 / num));
		Id = id;
		Statistics = new NetStatistics();
		_packetPool = netManager.NetPacketPool;
		NetManager = netManager;
		if (netManager.MtuOverride > 0)
		{
			OverrideMtu(netManager.MtuOverride);
		}
		else if (netManager.UseSafeMtu)
		{
			SetMtu(0);
		}
		else
		{
			SetMtu(1);
		}
		EndPoint = remoteEndPoint;
		_connectionState = ConnectionState.Connected;
		_mergeData = new NetPacket(PacketProperty.Merged, NetConstants.MaxPacketSize);
		_pongPacket = new NetPacket(PacketProperty.Pong, 0);
		_pingPacket = new NetPacket(PacketProperty.Ping, 0)
		{
			Sequence = 1
		};
		_unreliableChannel = new Queue<NetPacket>(64);
		_holdedFragments = new Dictionary<ushort, IncomingFragments>();
		_deliveredFragments = new Dictionary<ushort, ushort>();
		_channels = new BaseChannel[netManager.ChannelsCount * 4];
		_channelSendQueue = new Queue<BaseChannel>(netManager.ChannelsCount * 4);
	}

	private void SetMtu(int mtuIdx)
	{
		_mtuIdx = mtuIdx;
		_mtu = NetConstants.PossibleMtu[mtuIdx] - NetManager.ExtraPacketSizeForLayer;
	}

	private void OverrideMtu(int mtuValue)
	{
		_mtu = mtuValue;
		_finishMtu = true;
	}

	public int GetPacketsCountInReliableQueue(byte channelNumber, bool ordered)
	{
		int num = channelNumber * 4 + (ordered ? 2 : 0);
		BaseChannel baseChannel = _channels[num];
		if (baseChannel == null)
		{
			return 0;
		}
		return ((ReliableChannel)baseChannel).PacketsInQueue;
	}

	private BaseChannel CreateChannel(byte idx)
	{
		BaseChannel baseChannel = _channels[idx];
		if (baseChannel != null)
		{
			return baseChannel;
		}
		switch ((DeliveryMethod)(byte)(idx % 4))
		{
		case DeliveryMethod.ReliableUnordered:
			baseChannel = new ReliableChannel(this, ordered: false, idx);
			break;
		case DeliveryMethod.Sequenced:
			baseChannel = new SequencedChannel(this, reliable: false, idx);
			break;
		case DeliveryMethod.ReliableOrdered:
			baseChannel = new ReliableChannel(this, ordered: true, idx);
			break;
		case DeliveryMethod.ReliableSequenced:
			baseChannel = new SequencedChannel(this, reliable: true, idx);
			break;
		}
		BaseChannel baseChannel2 = Interlocked.CompareExchange(ref _channels[idx], baseChannel, null);
		if (baseChannel2 != null)
		{
			return baseChannel2;
		}
		return baseChannel;
	}

	internal NetPeer(NetManager netManager, IPEndPoint remoteEndPoint, int id, byte connectNum, NetDataWriter connectData)
		: this(netManager, remoteEndPoint, id)
	{
		_connectTime = DateTime.UtcNow.Ticks;
		_connectionState = ConnectionState.Outgoing;
		ConnectionNum = connectNum;
		_connectRequestPacket = NetConnectRequestPacket.Make(connectData, remoteEndPoint.Serialize(), _connectTime);
		_connectRequestPacket.ConnectionNumber = connectNum;
		NetManager.SendRaw(_connectRequestPacket, EndPoint);
	}

	internal NetPeer(NetManager netManager, IPEndPoint remoteEndPoint, int id, long connectId, byte connectNum)
		: this(netManager, remoteEndPoint, id)
	{
		_connectTime = connectId;
		_connectionState = ConnectionState.Connected;
		ConnectionNum = connectNum;
		_connectAcceptPacket = NetConnectAcceptPacket.Make(_connectTime, connectNum, reusedPeer: false);
		NetManager.SendRaw(_connectAcceptPacket, EndPoint);
	}

	internal void Reject(long connectionId, byte connectionNumber, byte[] data, int start, int length)
	{
		_connectTime = connectionId;
		_connectNum = connectionNumber;
		Shutdown(data, start, length, force: false);
	}

	internal bool ProcessConnectAccept(NetConnectAcceptPacket packet)
	{
		if (_connectionState != ConnectionState.Outgoing)
		{
			return false;
		}
		if (packet.ConnectionId != _connectTime)
		{
			return false;
		}
		ConnectionNum = packet.ConnectionNumber;
		Interlocked.Exchange(ref _timeSinceLastPacket, 0);
		_connectionState = ConnectionState.Connected;
		return true;
	}

	public int GetMaxSinglePacketSize(DeliveryMethod options)
	{
		return _mtu - NetPacket.GetHeaderSize((options != DeliveryMethod.Unreliable) ? PacketProperty.Channeled : PacketProperty.Unreliable);
	}

	public void SendWithDeliveryEvent(byte[] data, byte channelNumber, DeliveryMethod deliveryMethod, object userData)
	{
		if (deliveryMethod != DeliveryMethod.ReliableOrdered && deliveryMethod != DeliveryMethod.ReliableUnordered)
		{
			throw new ArgumentException("Delivery event will work only for ReliableOrdered/Unordered packets");
		}
		SendInternal(data, 0, data.Length, channelNumber, deliveryMethod, userData, null);
	}

	public void SendWithDeliveryEvent(byte[] data, int start, int length, byte channelNumber, DeliveryMethod deliveryMethod, object userData)
	{
		if (deliveryMethod != DeliveryMethod.ReliableOrdered && deliveryMethod != DeliveryMethod.ReliableUnordered)
		{
			throw new ArgumentException("Delivery event will work only for ReliableOrdered/Unordered packets");
		}
		SendInternal(data, start, length, channelNumber, deliveryMethod, userData, null);
	}

	public void SendWithDeliveryEvent(NetDataWriter dataWriter, byte channelNumber, DeliveryMethod deliveryMethod, object userData)
	{
		if (deliveryMethod != DeliveryMethod.ReliableOrdered && deliveryMethod != DeliveryMethod.ReliableUnordered)
		{
			throw new ArgumentException("Delivery event will work only for ReliableOrdered/Unordered packets");
		}
		SendInternal(dataWriter.Data, 0, dataWriter.Length, channelNumber, deliveryMethod, userData, null);
	}

	public void Send(byte[] data, DeliveryMethod deliveryMethod)
	{
		SendInternal(data, 0, data.Length, 0, deliveryMethod, null, null);
	}

	public void Send(NetDataWriter dataWriter, DeliveryMethod deliveryMethod)
	{
		SendInternal(dataWriter.Data, 0, dataWriter.Length, 0, deliveryMethod, null, null);
	}

	public void Send(byte[] data, int start, int length, DeliveryMethod options)
	{
		SendInternal(data, start, length, 0, options, null, null);
	}

	public void Send(ByteBuffer data, byte channelNumber, DeliveryMethod deliveryMethod)
	{
		if (deliveryMethod == DeliveryMethod.ReliableOrdered && _reliableBytesSinceLastUpdate >= _reliableBytesPerUpdate)
		{
			lock (_bandwidthDelayedMessages)
			{
				DelayMessage(data, channelNumber);
				return;
			}
		}
		ByteBuffer byteBuffer = data;
		byte channelNumber2 = channelNumber;
		if (deliveryMethod == DeliveryMethod.ReliableOrdered && _bandwidthDelayedMessages.Count > 0)
		{
			lock (_bandwidthDelayedMessages)
			{
				if (_bandwidthDelayedMessages.Count > 0)
				{
					(byteBuffer, channelNumber2) = _bandwidthDelayedMessages.Dequeue();
					DelayMessage(data, channelNumber);
				}
			}
		}
		SendInternal(byteBuffer.Data, 0, byteBuffer.DataLength, channelNumber2, deliveryMethod, null, byteBuffer);
		Interlocked.Add(ref _reliableBytesSinceLastUpdate, byteBuffer.DataLength);
	}

	private void DelayMessage(ByteBuffer data, byte channelNumber)
	{
		data.MarkAsDelayed(this);
		_amountOfDelayedBytes += data.Length;
		_bandwidthDelayedMessages.Enqueue((data, channelNumber));
	}

	public void Send(NetDataWriter dataWriter, byte channelNumber, DeliveryMethod deliveryMethod)
	{
		SendInternal(dataWriter.Data, 0, dataWriter.Length, channelNumber, deliveryMethod, null, null);
	}

	public void Send(byte[] data, int start, int length, byte channelNumber, DeliveryMethod deliveryMethod)
	{
		SendInternal(data, start, length, channelNumber, deliveryMethod, null, null);
	}

	private void SendInternal(byte[] data, int start, int length, byte channelNumber, DeliveryMethod deliveryMethod, object userData, ByteBuffer byteBuffer)
	{
		try
		{
			if (_connectionState != ConnectionState.Connected || channelNumber >= _channels.Length)
			{
				return;
			}
			BaseChannel baseChannel = null;
			PacketProperty property;
			if (deliveryMethod == DeliveryMethod.Unreliable)
			{
				property = PacketProperty.Unreliable;
			}
			else
			{
				property = PacketProperty.Channeled;
				baseChannel = CreateChannel((byte)((uint)(channelNumber * 4) + (uint)deliveryMethod));
			}
			int headerSize = NetPacket.GetHeaderSize(property);
			int mtu = _mtu;
			if (length + headerSize > mtu)
			{
				if (deliveryMethod != DeliveryMethod.ReliableOrdered && deliveryMethod != DeliveryMethod.ReliableUnordered)
				{
					throw new TooBigPacketException("Unreliable or ReliableSequenced packet size exceeded maximum of " + (mtu - headerSize) + " bytes, Check allowed size by GetMaxSinglePacketSize()");
				}
				int num = mtu - headerSize - 6;
				int num2 = length / num + ((length % num != 0) ? 1 : 0);
				if (num2 > 65535)
				{
					throw new TooBigPacketException("Data was split in " + num2 + " fragments, which exceeds " + ushort.MaxValue);
				}
				ushort fragmentId = (ushort)Interlocked.Increment(ref _fragmentId);
				for (ushort num3 = 0; num3 < num2; num3++)
				{
					int num4 = ((length > num) ? num : length);
					NetPacket packet = _packetPool.GetPacket(headerSize + num4 + 6);
					packet.Property = property;
					packet.UserData = userData;
					packet.FragmentId = fragmentId;
					packet.FragmentPart = num3;
					packet.FragmentsTotal = (ushort)num2;
					packet.MarkFragmented();
					Buffer.BlockCopy(data, start + num3 * num, packet.RawData, 10, num4);
					baseChannel.AddToQueue(packet);
					length -= num4;
				}
				return;
			}
			NetPacket packet2 = _packetPool.GetPacket(headerSize + length);
			packet2.Property = property;
			Buffer.BlockCopy(data, start, packet2.RawData, headerSize, length);
			packet2.UserData = userData;
			if (baseChannel == null)
			{
				lock (_unreliableChannel)
				{
					_unreliableChannel.Enqueue(packet2);
					return;
				}
			}
			baseChannel.AddToQueue(packet2);
		}
		catch (Exception)
		{
			byteBuffer?.MarkSent(this);
			throw;
		}
		finally
		{
			byteBuffer?.MarkSent(this);
		}
	}

	public void Disconnect(byte[] data)
	{
		NetManager.DisconnectPeer(this, data);
	}

	public void Disconnect(NetDataWriter writer)
	{
		NetManager.DisconnectPeer(this, writer);
	}

	public void Disconnect(byte[] data, int start, int count)
	{
		NetManager.DisconnectPeer(this, data, start, count);
	}

	public void Disconnect()
	{
		NetManager.DisconnectPeer(this);
	}

	internal DisconnectResult ProcessDisconnect(NetPacket packet)
	{
		if ((_connectionState == ConnectionState.Connected || _connectionState == ConnectionState.Outgoing) && packet.Size >= 9 && BitConverter.ToInt64(packet.RawData, 1) == _connectTime && packet.ConnectionNumber == _connectNum)
		{
			if (_connectionState != ConnectionState.Connected)
			{
				return DisconnectResult.Reject;
			}
			return DisconnectResult.Disconnect;
		}
		return DisconnectResult.None;
	}

	internal void AddToReliableChannelSendQueue(BaseChannel channel)
	{
		lock (_channelSendQueue)
		{
			_channelSendQueue.Enqueue(channel);
		}
	}

	internal ShutdownResult Shutdown(byte[] data, int start, int length, bool force)
	{
		lock (_bandwidthDelayedMessages)
		{
			try
			{
				while (_bandwidthDelayedMessages.Count > 0)
				{
					_bandwidthDelayedMessages.Dequeue().data.MarkSent(this);
				}
			}
			catch (Exception e)
			{
				App.Logging.Logger.Exception(e);
				App.Logging.Logger.Error("FATAL: issue releasing delayed messages on client disconnection");
			}
		}
		lock (_shutdownLock)
		{
			if (_connectionState == ConnectionState.Disconnected || _connectionState == ConnectionState.ShutdownRequested)
			{
				return ShutdownResult.None;
			}
			ShutdownResult result = ((_connectionState != ConnectionState.Connected) ? ShutdownResult.Success : ShutdownResult.WasConnected);
			if (force)
			{
				_connectionState = ConnectionState.Disconnected;
				return result;
			}
			Interlocked.Exchange(ref _timeSinceLastPacket, 0);
			_shutdownPacket = new NetPacket(PacketProperty.Disconnect, length)
			{
				ConnectionNumber = _connectNum
			};
			FastBitConverter.GetBytes(_shutdownPacket.RawData, 1, _connectTime);
			if (_shutdownPacket.Size >= _mtu)
			{
				NetDebug.WriteError("[Peer] Disconnect additional data size more than MTU - 8!");
			}
			else if (data != null && length > 0)
			{
				Buffer.BlockCopy(data, start, _shutdownPacket.RawData, 9, length);
			}
			_connectionState = ConnectionState.ShutdownRequested;
			NetManager.SendRaw(_shutdownPacket, EndPoint);
			return result;
		}
	}

	private void UpdateRoundTripTime(int roundTripTime)
	{
		_rtt += roundTripTime;
		_rttCount++;
		_avgRtt = _rtt / _rttCount;
		_resendDelay = 25.0 + (double)_avgRtt * 2.1;
	}

	internal void AddReliablePacket(DeliveryMethod method, NetPacket p)
	{
		if (p.IsFragmented)
		{
			ushort fragmentId = p.FragmentId;
			if (!_holdedFragments.TryGetValue(fragmentId, out var value))
			{
				value = new IncomingFragments
				{
					Fragments = new NetPacket[p.FragmentsTotal],
					ChannelId = p.ChannelId
				};
				_holdedFragments.Add(fragmentId, value);
			}
			NetPacket[] fragments = value.Fragments;
			if (p.FragmentPart >= fragments.Length || fragments[p.FragmentPart] != null || p.ChannelId != value.ChannelId)
			{
				_packetPool.Recycle(p);
				NetDebug.WriteError("Invalid fragment packet");
				return;
			}
			fragments[p.FragmentPart] = p;
			value.ReceivedCount++;
			value.TotalSize += p.Size - 10;
			if (value.ReceivedCount != fragments.Length)
			{
				return;
			}
			NetPacket packet = _packetPool.GetPacket(value.TotalSize);
			int num = 0;
			for (int i = 0; i < value.ReceivedCount; i++)
			{
				NetPacket netPacket = fragments[i];
				int num2 = netPacket.Size - 10;
				if (num + num2 > packet.RawData.Length)
				{
					_holdedFragments.Remove(fragmentId);
					NetDebug.WriteError("Fragment error pos: {0} >= resultPacketSize: {1} , totalSize: {2}", num + num2, packet.RawData.Length, value.TotalSize);
					return;
				}
				Buffer.BlockCopy(netPacket.RawData, 10, packet.RawData, num, num2);
				num += num2;
				_packetPool.Recycle(netPacket);
				fragments[i] = null;
			}
			_holdedFragments.Remove(fragmentId);
			NetManager.CreateReceiveEvent(packet, method, 0, this);
		}
		else
		{
			NetManager.CreateReceiveEvent(p, method, 4, this);
		}
	}

	private void ProcessMtuPacket(NetPacket packet)
	{
		if (packet.Size < NetConstants.PossibleMtu[0])
		{
			return;
		}
		int num = BitConverter.ToInt32(packet.RawData, 1);
		int num2 = BitConverter.ToInt32(packet.RawData, packet.Size - 4);
		if (num != packet.Size || num != num2 || num > NetConstants.MaxPacketSize)
		{
			NetDebug.WriteError("[MTU] Broken packet. RMTU {0}, EMTU {1}, PSIZE {2}", num, num2, packet.Size);
		}
		else if (packet.Property == PacketProperty.MtuCheck)
		{
			_mtuCheckAttempts = 0;
			packet.Property = PacketProperty.MtuOk;
			NetManager.SendRawAndRecycle(packet, EndPoint);
		}
		else if (num > _mtu && !_finishMtu && num == NetConstants.PossibleMtu[_mtuIdx + 1])
		{
			lock (_mtuMutex)
			{
				SetMtu(_mtuIdx + 1);
			}
			if (_mtuIdx == NetConstants.PossibleMtu.Length - 1)
			{
				_finishMtu = true;
			}
		}
	}

	private void UpdateMtuLogic(int deltaTime)
	{
		if (_finishMtu)
		{
			return;
		}
		_mtuCheckTimer += deltaTime;
		if (_mtuCheckTimer < 1000)
		{
			return;
		}
		_mtuCheckTimer = 0;
		_mtuCheckAttempts++;
		if (_mtuCheckAttempts >= 4)
		{
			_finishMtu = true;
			return;
		}
		lock (_mtuMutex)
		{
			if (_mtuIdx < NetConstants.PossibleMtu.Length - 1)
			{
				int num = NetConstants.PossibleMtu[_mtuIdx + 1] - NetManager.ExtraPacketSizeForLayer;
				NetPacket packet = _packetPool.GetPacket(num);
				packet.Property = PacketProperty.MtuCheck;
				FastBitConverter.GetBytes(packet.RawData, 1, num);
				FastBitConverter.GetBytes(packet.RawData, packet.Size - 4, num);
				if (NetManager.SendRawAndRecycle(packet, EndPoint) <= 0)
				{
					_finishMtu = true;
				}
			}
		}
	}

	internal ConnectRequestResult ProcessConnectRequest(NetConnectRequestPacket connRequest)
	{
		switch (_connectionState)
		{
		case ConnectionState.Outgoing:
		{
			if (connRequest.ConnectionTime < _connectTime)
			{
				return ConnectRequestResult.P2PLose;
			}
			if (connRequest.ConnectionTime != _connectTime)
			{
				break;
			}
			SocketAddress socketAddress = EndPoint.Serialize();
			byte[] targetAddress = connRequest.TargetAddress;
			for (int num = socketAddress.Size - 1; num >= 0; num--)
			{
				byte b = socketAddress[num];
				if (b != targetAddress[num] && b < targetAddress[num])
				{
					return ConnectRequestResult.P2PLose;
				}
			}
			break;
		}
		case ConnectionState.Connected:
			if (connRequest.ConnectionTime == _connectTime)
			{
				NetManager.SendRaw(_connectAcceptPacket, EndPoint);
			}
			else if (connRequest.ConnectionTime > _connectTime)
			{
				return ConnectRequestResult.Reconnection;
			}
			break;
		case ConnectionState.ShutdownRequested:
		case ConnectionState.Disconnected:
			if (connRequest.ConnectionTime >= _connectTime)
			{
				return ConnectRequestResult.NewConnection;
			}
			break;
		}
		return ConnectRequestResult.None;
	}

	internal void ProcessPacket(NetPacket packet)
	{
		if (_connectionState == ConnectionState.Outgoing || _connectionState == ConnectionState.Disconnected)
		{
			_packetPool.Recycle(packet);
			return;
		}
		if (packet.Property == PacketProperty.ShutdownOk)
		{
			if (_connectionState == ConnectionState.ShutdownRequested)
			{
				_connectionState = ConnectionState.Disconnected;
			}
			_packetPool.Recycle(packet);
			return;
		}
		if (packet.ConnectionNumber != _connectNum)
		{
			_packetPool.Recycle(packet);
			return;
		}
		Interlocked.Exchange(ref _timeSinceLastPacket, 0);
		switch (packet.Property)
		{
		case PacketProperty.Merged:
		{
			int num2 = 1;
			while (num2 < packet.Size)
			{
				ushort num3 = BitConverter.ToUInt16(packet.RawData, num2);
				num2 += 2;
				if (packet.RawData.Length - num2 < num3)
				{
					break;
				}
				NetPacket packet2 = _packetPool.GetPacket(num3);
				Buffer.BlockCopy(packet.RawData, num2, packet2.RawData, 0, num3);
				packet2.Size = num3;
				if (!packet2.Verify())
				{
					break;
				}
				num2 += num3;
				ProcessPacket(packet2);
			}
			_packetPool.Recycle(packet);
			break;
		}
		case PacketProperty.Ping:
			if (NetUtils.RelativeSequenceNumber(packet.Sequence, _pongPacket.Sequence) > 0)
			{
				FastBitConverter.GetBytes(_pongPacket.RawData, 3, DateTime.UtcNow.Ticks);
				_pongPacket.Sequence = packet.Sequence;
				NetManager.SendRaw(_pongPacket, EndPoint);
			}
			_packetPool.Recycle(packet);
			break;
		case PacketProperty.Pong:
			if (packet.Sequence == _pingPacket.Sequence)
			{
				_pingTimer.Stop();
				int num = (int)_pingTimer.ElapsedMilliseconds;
				_remoteDelta = BitConverter.ToInt64(packet.RawData, 3) + (long)num * 10000L / 2 - DateTime.UtcNow.Ticks;
				UpdateRoundTripTime(num);
				NetManager.ConnectionLatencyUpdated(this, num / 2);
			}
			_packetPool.Recycle(packet);
			break;
		case PacketProperty.Channeled:
		case PacketProperty.Ack:
		{
			if (packet.ChannelId >= _channels.Length)
			{
				_packetPool.Recycle(packet);
				break;
			}
			BaseChannel baseChannel = _channels[packet.ChannelId] ?? ((packet.Property == PacketProperty.Ack) ? null : CreateChannel(packet.ChannelId));
			if (baseChannel != null && !baseChannel.ProcessPacket(packet))
			{
				_packetPool.Recycle(packet);
			}
			break;
		}
		case PacketProperty.Unreliable:
			NetManager.CreateReceiveEvent(packet, DeliveryMethod.Unreliable, 1, this);
			break;
		case PacketProperty.MtuCheck:
		case PacketProperty.MtuOk:
			ProcessMtuPacket(packet);
			break;
		default:
			NetDebug.WriteError("Error! Unexpected packet type: " + packet.Property);
			break;
		}
	}

	private void SendMerged()
	{
		if (_mergeCount != 0)
		{
			int num = ((_mergeCount <= 1) ? NetManager.SendRaw(_mergeData.RawData, 3, _mergePos - 2, EndPoint) : NetManager.SendRaw(_mergeData.RawData, 0, 1 + _mergePos, EndPoint));
			if (NetManager.EnableStatistics)
			{
				Statistics.IncrementPacketsSent();
				Statistics.AddBytesSent(num);
			}
			_mergePos = 0;
			_mergeCount = 0;
		}
	}

	internal void SendUserData(NetPacket packet)
	{
		packet.ConnectionNumber = _connectNum;
		int num = 1 + packet.Size + 2;
		if (num + 20 >= _mtu)
		{
			int num2 = NetManager.SendRaw(packet, EndPoint);
			if (NetManager.EnableStatistics)
			{
				Statistics.IncrementPacketsSent();
				Statistics.AddBytesSent(num2);
			}
			return;
		}
		if (_mergePos + num > _mtu)
		{
			SendMerged();
		}
		FastBitConverter.GetBytes(_mergeData.RawData, _mergePos + 1, (ushort)packet.Size);
		Buffer.BlockCopy(packet.RawData, 0, _mergeData.RawData, _mergePos + 1 + 2, packet.Size);
		_mergePos += packet.Size + 2;
		_mergeCount++;
	}

	internal void Update(int deltaTime)
	{
		Interlocked.Add(ref _timeSinceLastPacket, deltaTime);
		switch (_connectionState)
		{
		case ConnectionState.Connected:
			if (_timeSinceLastPacket > NetManager.DisconnectTimeout)
			{
				NetManager.DisconnectPeerForce(this, DisconnectReason.Timeout, SocketError.Success, null);
				return;
			}
			break;
		case ConnectionState.ShutdownRequested:
			if (_timeSinceLastPacket > NetManager.DisconnectTimeout)
			{
				_connectionState = ConnectionState.Disconnected;
				return;
			}
			_shutdownTimer += deltaTime;
			if (_shutdownTimer >= 300)
			{
				_shutdownTimer = 0;
				NetManager.SendRaw(_shutdownPacket, EndPoint);
			}
			return;
		case ConnectionState.Outgoing:
			_connectTimer += deltaTime;
			if (_connectTimer > NetManager.ReconnectDelay)
			{
				_connectTimer = 0;
				_connectAttempts++;
				if (_connectAttempts > NetManager.MaxConnectAttempts)
				{
					NetManager.DisconnectPeerForce(this, DisconnectReason.ConnectionFailed, SocketError.Success, null);
				}
				else
				{
					NetManager.SendRaw(_connectRequestPacket, EndPoint);
				}
			}
			return;
		case ConnectionState.Disconnected:
			return;
		}
		_pingSendTimer += deltaTime;
		if (_pingSendTimer >= NetManager.PingInterval)
		{
			_pingSendTimer = 0;
			_pingPacket.Sequence++;
			if (_pingTimer.IsRunning)
			{
				UpdateRoundTripTime((int)_pingTimer.ElapsedMilliseconds);
			}
			_pingTimer.Reset();
			_pingTimer.Start();
			NetManager.SendRaw(_pingPacket, EndPoint);
		}
		_rttResetTimer += deltaTime;
		if (_rttResetTimer >= NetManager.PingInterval * 3)
		{
			_rttResetTimer = 0;
			_rtt = _avgRtt;
			_rttCount = 1;
		}
		UpdateMtuLogic(deltaTime);
		if (_channelSendQueue.Count > 0)
		{
			lock (_channelSendQueue)
			{
				int count = _channelSendQueue.Count;
				while (count-- > 0)
				{
					BaseChannel baseChannel = _channelSendQueue.Dequeue();
					if (baseChannel.SendAndCheckQueue())
					{
						_channelSendQueue.Enqueue(baseChannel);
					}
				}
			}
		}
		if (_unreliableChannel.Count > 0)
		{
			lock (_unreliableChannel)
			{
				while (_unreliableChannel.Count > 0)
				{
					NetPacket packet = _unreliableChannel.Dequeue();
					SendUserData(packet);
					NetManager.NetPacketPool.Recycle(packet);
				}
			}
		}
		SendMerged();
		if (_bandwidthDelayedMessages.Count > 0)
		{
			lock (_bandwidthDelayedMessages)
			{
				_ = _amountOfDelayedBytes;
				int num = 0;
				while (_bandwidthDelayedMessages.Count > 0 && num < _reliableBytesPerUpdate)
				{
					(ByteBuffer, byte) tuple = _bandwidthDelayedMessages.Dequeue();
					_amountOfDelayedBytes -= tuple.Item1.DataLength;
					num += tuple.Item1.DataLength;
					SendInternal(tuple.Item1.Data, 0, tuple.Item1.DataLength, tuple.Item2, DeliveryMethod.ReliableOrdered, null, tuple.Item1);
				}
			}
		}
		Interlocked.Exchange(ref _reliableBytesSinceLastUpdate, 0);
	}

	internal void RecycleAndDeliver(NetPacket packet)
	{
		if (packet.UserData != null)
		{
			if (packet.IsFragmented)
			{
				_deliveredFragments.TryGetValue(packet.FragmentId, out var value);
				value++;
				if (value == packet.FragmentsTotal)
				{
					NetManager.MessageDelivered(this, packet.UserData);
					_deliveredFragments.Remove(packet.FragmentId);
				}
				else
				{
					_deliveredFragments[packet.FragmentId] = value;
				}
			}
			else
			{
				NetManager.MessageDelivered(this, packet.UserData);
			}
			packet.UserData = null;
		}
		_packetPool.Recycle(packet);
	}
}
