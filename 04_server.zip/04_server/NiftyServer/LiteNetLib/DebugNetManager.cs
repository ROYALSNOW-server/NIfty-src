using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using App.Logging;
using LiteNetLib.Layers;

namespace LiteNetLib;

public class DebugNetManager(INetEventListener listener, PacketLayerBase extraPacketLayer = null) : NetManager(listener, extraPacketLayer)
{
	private struct IncomingData
	{
		public NetPacket Data;

		public IPEndPoint EndPoint;

		public DateTime TimeWhenGet;
	}

	private readonly List<IncomingData> _pingSimulationList = new List<IncomingData>();

	private readonly Random _randomGenerator = new Random();

	private const int MinLatencyThreshold = 5;

	protected override void ProcessDelayedPackets()
	{
		if (!SimulateLatency)
		{
			return;
		}
		DateTime utcNow = DateTime.UtcNow;
		lock (_pingSimulationList)
		{
			for (int i = 0; i < _pingSimulationList.Count; i++)
			{
				IncomingData incomingData = _pingSimulationList[i];
				if (incomingData.TimeWhenGet <= utcNow)
				{
					DataReceived(incomingData.Data, incomingData.EndPoint);
					_pingSimulationList.RemoveAt(i);
					i--;
				}
			}
		}
	}

	internal override bool OnInternalMessageReceived(NetPacket packet, SocketError errorCode, IPEndPoint remoteEndPoint)
	{
		if (SimulatePacketLoss && _randomGenerator.NextDouble() * 100.0 < (double)SimulationPacketLossChance)
		{
			return false;
		}
		if (SimulateLatency)
		{
			try
			{
				int num = _randomGenerator.Next(SimulationMinLatency, SimulationMaxLatency);
				if (num > 5)
				{
					lock (_pingSimulationList)
					{
						_pingSimulationList.Add(new IncomingData
						{
							Data = packet,
							EndPoint = remoteEndPoint,
							TimeWhenGet = DateTime.UtcNow.AddMilliseconds(num)
						});
					}
					return false;
				}
			}
			catch (ArgumentOutOfRangeException)
			{
				Logger.Warn("Latency simulation minimum value must be greater than maximum.");
			}
		}
		return true;
	}

	protected override void OnStop()
	{
		lock (_pingSimulationList)
		{
			_pingSimulationList.Clear();
		}
	}
}
