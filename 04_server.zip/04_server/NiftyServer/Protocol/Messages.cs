using System.Text;

namespace NiftyServer.Protocol
{
    /// <summary>LiteNetLib channel map, from Transport.Common NetworkChannels + NetPeerConnectionImpl.</summary>
    public static class Channels
    {
        public const byte State = 0;   // SendState / SendEvent  -> Unreliable
        public const byte Command = 1; // SendCommand            -> ReliableOrdered
        public const byte Admin = 2;   // SendAdminCommand       -> ReliableOrdered (reserved)
    }

    /// <summary>
    /// Concrete example message, byte-for-byte compatible with the decompiled
    /// <c>GameInterface.Common.GameSessionCommand</c>:
    ///   [0..2) ushort MessageId  [2..4) ushort len(0xFFFF=null)  [4..) UTF-8 Id
    /// Use this as the template for porting the rest of the ISmallBuffer catalogue.
    /// </summary>
    public static class GameSessionCommand
    {
        public static readonly ushort MessageId = NiftyWire.StableHash16("GameSessionCommand");

        public static bool Matches(byte[] payload) => NiftyWire.MessageId(payload) == MessageId;

        public static byte[] Create(string id)
        {
            ushort len = id == null ? NiftyWire.NullLength : (ushort)Encoding.UTF8.GetByteCount(id);
            int bodyLen = id == null ? 0 : len;
            var b = new byte[4 + bodyLen];
            NiftyWire.PutUshort(b, 0, MessageId);
            NiftyWire.PutUshort(b, 2, len);
            if (id != null) NiftyWire.PutStringUTF8(b, 4, id);
            return b;
        }

        public static string ReadId(byte[] payload)
        {
            ushort len = NiftyWire.GetObjectLength(payload, 2);
            return len == 0 ? null : NiftyWire.GetStringUTF8(payload, 4, len);
        }
    }
}
