using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

namespace NiftyServer.Protocol
{
    /// <summary>
    /// The full catalogue of the game's 988 network message types, resolved to
    /// their 16-bit MessageIds using the exact client hash (NiftyWire.StableHash16).
    ///
    /// This lets the server log human-readable message names instead of raw hex —
    /// which is what makes a packet capture actually readable. Load it once at
    /// startup: <c>MessageCatalogue.Default</c>.
    ///
    /// ⚠ Collisions: with 988 names in a 16-bit space a handful hash-collide. The
    /// client resolves these at runtime by re-hashing losers (name + n) in
    /// assembly-scan order (see SmallBuffersMessageIds.RemapCollidingMessageIds).
    /// We can't perfectly reproduce that order statically, so colliding ids are
    /// marked AMBIGUOUS here — confirm those specific messages against a capture.
    /// </summary>
    public sealed class MessageCatalogue
    {
        private static readonly Lazy<MessageCatalogue> _default = new(() => new MessageCatalogue(LoadNames()));
        public static MessageCatalogue Default => _default.Value;

        private readonly Dictionary<ushort, List<string>> _byId = new();
        private readonly Dictionary<string, ushort> _byName = new(StringComparer.Ordinal);

        public IReadOnlyCollection<string> Names => _byName.Keys;
        public int Count => _byName.Count;

        public MessageCatalogue(IEnumerable<string> names)
        {
            foreach (string name in names)
            {
                if (string.IsNullOrWhiteSpace(name)) continue;
                ushort id = NiftyWire.StableHash16(name);
                _byName[name] = id;
                if (!_byId.TryGetValue(id, out var list)) { list = new List<string>(); _byId[id] = list; }
                if (!list.Contains(name)) list.Add(name);
            }
        }

        /// <summary>True if the id maps to exactly one known message.</summary>
        public bool TryGetName(ushort id, out string name)
        {
            if (_byId.TryGetValue(id, out var list) && list.Count == 1) { name = list[0]; return true; }
            name = null;
            return false;
        }

        public ushort IdOf(string name) => _byName[name];

        /// <summary>Human-readable label for logs: name, name(AMBIGUOUS:...) or 0xXXXX.</summary>
        public string Describe(ushort id)
        {
            if (_byId.TryGetValue(id, out var list))
                return list.Count == 1 ? list[0] : $"AMBIGUOUS[{string.Join("|", list)}]";
            return $"0x{id:X4}";
        }

        public IEnumerable<(ushort Id, IReadOnlyList<string> Names)> Collisions() =>
            _byId.Where(kv => kv.Value.Count > 1).Select(kv => (kv.Key, (IReadOnlyList<string>)kv.Value));

        /// <summary>Category from the naming convention: Command (reliable), State (replicated), or Other.</summary>
        public static string Category(string name) =>
            name.EndsWith("Command", StringComparison.Ordinal) ? "Command" :
            name.EndsWith("State", StringComparison.Ordinal) ? "State" : "Other";

        /// <summary>Write a Markdown catalogue (id, name, category), collisions called out.</summary>
        public void WriteMarkdown(string path)
        {
            var sb = new StringBuilder();
            sb.AppendLine("# Nifty Island — Message Catalogue (auto-generated)");
            sb.AppendLine();
            sb.AppendLine($"{Count} message types. MessageId = StableHash16(typeName) (FNV-32 folded to 16 bits).");
            sb.AppendLine("Channels: `*Command` → reliable (ch1), `*State` → replicated (mostly ch0).");
            sb.AppendLine();
            var collisions = Collisions().ToList();
            sb.AppendLine($"Hash collisions: {collisions.Count} id(s) — see end; confirm those against a capture.");
            sb.AppendLine();
            sb.AppendLine("| MessageId | Type | Category |");
            sb.AppendLine("|-----------|------|----------|");
            foreach (var name in _byName.Keys.OrderBy(n => n, StringComparer.Ordinal))
                sb.AppendLine($"| 0x{_byName[name]:X4} | {name} | {Category(name)} |");
            if (collisions.Count > 0)
            {
                sb.AppendLine();
                sb.AppendLine("## Colliding ids (AMBIGUOUS — client remaps at runtime)");
                foreach (var (id, names) in collisions)
                    sb.AppendLine($"- 0x{id:X4}: {string.Join(", ", names)}");
            }
            File.WriteAllText(path, sb.ToString());
        }

        private static IEnumerable<string> LoadNames()
        {
            var asm = Assembly.GetExecutingAssembly();
            string res = asm.GetManifestResourceNames()
                            .FirstOrDefault(n => n.EndsWith("message_types.txt", StringComparison.OrdinalIgnoreCase));
            if (res == null) return Array.Empty<string>();
            using var s = asm.GetManifestResourceStream(res);
            using var r = new StreamReader(s);
            return r.ReadToEnd()
                    .Split('\n')
                    .Select(l => l.Trim())
                    .Where(l => l.Length > 0)
                    .ToList();
        }
    }
}
