using System;
using System.Text;

namespace NiftyServer.Protocol
{
    /// <summary>
    /// Self-contained port of Nifty Island's on-the-wire message framing, taken
    /// from the decompiled <c>Transport.Common.ByteBuffer</c> +
    /// <c>App.Utils.HashCode</c>. Engine-free (no Unity dependency).
    ///
    /// Wire facts (see 03_docs/04_WIRE_PROTOCOL.md):
    ///  - little-endian, offset-addressed
    ///  - every message begins with ushort MessageId @0 (= StableHash16(typeName))
    ///  - strings: ushort length prefix (0xFFFF = null) then UTF-8 bytes
    /// </summary>
    public static class NiftyWire
    {
        public const int DefaultPort = 3500;
        public const ushort NullLength = 0xFFFF;

        // ---- MessageId hashing (must match the client exactly) ----------------
        // FNV-32 over the string's UTF-16 code units, folded to 16 bits.
        public static uint StableHash32(string txt)
        {
            uint h = 2166136261u;
            foreach (char c in txt)
            {
                h *= 16777619u;
                h ^= c;
            }
            return h;
        }

        public static ushort StableHash16(string txt)
        {
            uint h = StableHash32(txt);
            return (ushort)((h >> 16) ^ h);
        }

        // ---- primitive reads (little-endian) ----------------------------------
        public static ushort GetUshort(byte[] b, int i) => (ushort)(b[i] | (b[i + 1] << 8));
        public static short GetShort(byte[] b, int i) => (short)(b[i] | (b[i + 1] << 8));
        public static int GetInt(byte[] b, int i) =>
            b[i] | (b[i + 1] << 8) | (b[i + 2] << 16) | (b[i + 3] << 24);
        public static uint GetUint(byte[] b, int i) => (uint)GetInt(b, i);
        public static long GetLong(byte[] b, int i)
        {
            long lo = (uint)GetInt(b, i);
            long hi = (uint)GetInt(b, i + 4);
            return lo | (hi << 32);
        }
        public static unsafe float GetFloat(byte[] b, int i)
        {
            int v = GetInt(b, i);
            return *(float*)&v;
        }

        /// <summary>Object-length field: 0xFFFF sentinel decodes to 0 (null).</summary>
        public static ushort GetObjectLength(byte[] b, int i)
        {
            ushort n = GetUshort(b, i);
            return n == NullLength ? (ushort)0 : n;
        }

        public static string GetStringUTF8(byte[] b, int start, int len) =>
            Encoding.UTF8.GetString(b, start, len);

        // ---- primitive writes (little-endian) ---------------------------------
        public static void PutUshort(byte[] b, int i, ushort v)
        {
            b[i] = (byte)v;
            b[i + 1] = (byte)(v >> 8);
        }
        public static void PutInt(byte[] b, int i, int v)
        {
            b[i] = (byte)v;
            b[i + 1] = (byte)(v >> 8);
            b[i + 2] = (byte)(v >> 16);
            b[i + 3] = (byte)(v >> 24);
        }
        public static unsafe void PutFloat(byte[] b, int i, float v) => PutInt(b, i, *(int*)&v);

        public static int PutStringUTF8(byte[] b, int i, string s) =>
            Encoding.UTF8.GetBytes(s, 0, s.Length, b, i);

        /// <summary>Quantized float: 2 bytes if range&lt;=360, else 3 bytes. Matches ByteBuffer.PutQuantizedFloat.</summary>
        public static int PutQuantizedFloat(byte[] b, int i, float value, int min, int max)
        {
            int range = max - min;
            int bytes = 3, scale = 16777215;
            if (range <= 360) { bytes = 2; scale = 65535; }
            int q = (int)((value - min) / (float)(max - min) * scale);
            for (int k = 0; k < bytes; k++) b[i + k] = (byte)(q >> (8 * k));
            return bytes;
        }
        public static float GetQuantizedFloat(byte[] b, int i, int min, int max, int bytes)
        {
            int scale = bytes == 2 ? 65535 : 16777215;
            int q = 0;
            for (int k = 0; k < bytes; k++) q |= b[i + k] << (8 * k);
            return (float)q / scale * (max - min) + min;
        }

        // ---- read the message type id off any received payload ----------------
        public static ushort MessageId(byte[] payload) => GetUshort(payload, 0);
    }
}
