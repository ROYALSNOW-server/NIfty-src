using System;

// Engine-free stand-in for the game's App.Logging.Logger, referenced by the
// vendored LiteNetLib. Keeps the vendored source unmodified.
namespace App.Logging
{
    public static class Logger
    {
        public static void Log(string message) => Console.WriteLine("[lnl] " + message);
        public static void Warn(string message) => Console.WriteLine("[lnl][warn] " + message);
        public static void Error(string message) => Console.WriteLine("[lnl][error] " + message);
        public static void Exception(Exception e) => Console.WriteLine("[lnl][exception] " + e);
    }
}
