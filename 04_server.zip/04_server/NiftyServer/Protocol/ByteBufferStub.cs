using LiteNetLib;

// Minimal engine-free stand-in for the game's Transport.Common.ByteBuffer /
// ByteBufferPool. The vendored LiteNetLib references these types (Nifty wove
// their pooled buffer + bandwidth-throttling into NetPeer/NetDataReader). We only
// need it to *compile* and to back NetDataReader.GetDataBuffer(); the server's
// own send path uses the stock Send(byte[],...) overload, and reads payloads via
// reader.GetRemainingBytes(). So this stub never needs the real quantization code.
namespace Transport.Common
{
    public class ByteBuffer
    {
        public byte[] Data { get; private set; }
        public int DataLength { get; set; }
        public int Length => Data?.Length ?? 0;

        public ByteBuffer(int size)
        {
            Data = new byte[size];
            DataLength = size;
        }

        public void MarkAsDelayed(NetPeer peer) { }
        public void MarkSent(NetPeer peer) { }
        public void Release() { }
    }

    public sealed class ByteBufferPool
    {
        public static readonly ByteBufferPool Instance = new ByteBufferPool();
        public ByteBuffer Get(int size) => new ByteBuffer(size);
    }
}
