# Backend Map — Nifty Island v2.15.04

Every external service the client depends on, from static analysis of the
decompiled assemblies (`NiftyIsland.AppDef`, `NiftyIsland.WebRequests`,
`NiftyIsland.Transport.*`, `AmazonGameLiftSDKPlugin`, launcher/client configs).
Payloads still need confirmation with a live network capture (Phase 4).

## Environments discovered

The game's internal codename is **"niftypirates"**. Host patterns per environment:

| Env | API / hosts |
|-----|-------------|
| **prod** | `niftyisland.com`, `api.niftyisland.com`, `content.niftyisland.com`, `metadata.niftyisland.com`, `flags.niftyisland.com`, `downloads.niftyisland.com` |
| dev | `dev.niftypirates.io`, `api.niftydev1.link`, `content.niftydev1.link`, `metadata.niftyqa1.link` |
| qa | `qa.niftypirates.io`, `content.niftyqa1.link`, `metadata.niftyqa1.link` |
| staging | `staging.niftypirates.io`, `content.niftystaging1.link`, `metadata.niftystaging1.link` |

## Services

### Authentication
- **Purpose:** issue a bearer token used on every API call.
- **Model:** `Authorization: Bearer <token>` header (see `IWebRequestClient` in
  `NiftyIsland.AppDef`). Token can be refreshed from a response header that is
  parsed on `=`/`;` (cookie-style), via `SetAuthToken(HttpWebResponse)`.
- **Host:** likely `api.niftyisland.com` (login flow tied to Nifty account /
  wallet — this is a web3 title). **Confirm exact path via capture.**
- **Required offline?** Yes for anything account-bound; a replacement must mint a
  token the client accepts.

### Player accounts / profile / inventory / social
- Served by the REST API under `api.niftyisland.com`.
- Backing assemblies: `NiftyIsland.Application.User.*`,
  `NiftyIsland.Application.PlayerInventory.*`, `NiftyIsland.Application.Social.*`,
  `NiftyIsland.Core.User`.
- Save data: `NiftyIsland.Application.Infrastructure.Common.SaveData`.

### Island / world data & content delivery
- **Content:** `content.niftyisland.com` (asset/island bundles),
  `metadata.niftyisland.com` (item/NFT metadata).
- **Local assets:** most run-time content ships in the client via Unity
  Addressables (`StreamingAssets/aa`, catalog uses local `RuntimePath`) — good
  news for preservation, the bulk of content is already on disk.

### Multiplayer (the important one)
- **MatchMaker API:** `https://9ia2gjqr5l.execute-api.us-east-2.amazonaws.com/MatchMaker`
  (AWS API Gateway). Client requests an island → receives host+port of a
  dedicated server.
- **Game servers:** AWS **GameLift** EC2 fleets, e.g.
  `ec2-18-225-5-101.us-east-2.compute.amazonaws.com`. SDK:
  `AmazonGameLiftSDKPlugin.Runtime.dll`.
- **Transport:** realtime layer is **LiteNetLib (reliable UDP)**, vendored into
  `NiftyIsland.Transport.Common` (open-source lib — a community server can reuse
  it directly). On top sits a **command-schema** message system (`*CommandSchema`
  types, e.g. `EnvironmentInitCommandSchema`, `EnvironmentClientReadyCommandSchema`).
  `websocket-sharp` is present too but for a different channel (signaling / voice),
  not the game-state transport.
- **Direct connect:** client also supports raw IP+port (per the load-test bot
  usage string) — useful for pointing at a local server.

### Voice chat
- **Unity Vivox.** Config in `StreamingAssets/UnityServicesProjectConfiguration.json`:
  server `https://unity.vivox.com/appconfig/24744-nifty-41526-udash`,
  domain `mtu1xp.vivox.com`, issuer `24744-nifty-41526-udash`, env `production`.
- Also `DissonanceVoip.dll` present (alternate/legacy voice).

### Feature flags
- **ConfigCat** via proxy: `https://flags.niftyisland.com`, SDK key
  `configcat-proxy/game`, auto-poll every 10 min. (`NiftyIsland.AppDef` →
  `ConfigCatSdkWrapper`). A replacement can serve static flag JSON here.

### Logging / telemetry
- Logging API: `https://a01kfry225.execute-api.us-east-2.amazonaws.com/prod`
  — `POST /log-location` returns a presigned `uploadURL` (S3) that the client
  PUTs logs to. Non-essential for offline play; can be stubbed/no-op'd.
- Analytics: `Analytics.dll`, `NiftyIsland.Analytics.dll` (Segment prefs seen in
  launcher LocalLow). Non-essential.

### Misc / third-party
- **Discord:** `DiscordSDK.dll` (rich presence; Discord invite/channel links).
- **Status flags:** `downloads.niftyisland.com/game-status/game-status.txt` and
  `/wager-status/wager-status.txt` (plain-text kill-switches the client polls).
- **Web3:** `NiftyIsland.Nftables.dll` (1.5 MB) — on-chain item/NFT layer;
  external links to Uniswap. Preservation of on-chain features is out of scope
  for a simple community server.

## Priority for a minimum playable server
1. Auth (mint a token the client accepts)
2. Feature flags (`flags.niftyisland.com`) + status txt files (return "ok")
3. Player profile + one island (world load)
4. Transport/MatchMaker handshake → connect to a local game server
5. Movement / world state via the command-schema protocol
6. Save, inventory, social, voice — later
