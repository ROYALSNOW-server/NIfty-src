# Client Snapshot — Phase 1

## Version
- **Version.txt / v.txt:** `2.15.04`
- **build-guid:** `1987477470c64283bd4cf94a50134dbf` (from `boot.config`)
- **Engine:** **Unity 6000.0.58f2** (Unity 6), **Mono** scripting backend
  (Managed DLLs present; no `global-metadata.dat` / `GameAssembly.dll`).
- **Platform:** StandaloneWindows64
- Client binaries dated 2025-07-28.

### `NiftyIslandClient.exe`
- **Native** PE32+ x86-64 (7 sections) — Unity player bootstrap stub, **no
  managed metadata / no IL**. It only loads `UnityPlayer.dll` + the Mono runtime;
  it contains **no game logic** and cannot be decompiled to C#. All game code is
  the managed DLLs in `Managed/` (decompiled in `02_decompiled_src/`).
- Version resource: FileVersion `6000.0.58.9625317`, ProductVersion
  `6000.0.58f2 (92dee566b325)`, © 2005–2025 Unity Technologies (stock launcher).
- Size 672,256 bytes. SHA256
  `495F72B2189CFE7E2BB5745F289F27D9F68B29E68E25E6E917CE8EED1C7669C8`.
- Native disassembly (Ghidra/IDA) is possible but pointless here — it would only
  show generic engine bootstrap, not game code.

## Original location (untouched)
`C:\Users\Gunna\AppData\Roaming\Nifty Island\application\`
- `NiftyIslandClient.exe` (672 KB) + `UnityPlayer.dll` (33.7 MB)
- `NiftyIslandClient_Data\Managed\` — 368 managed DLLs
- `NiftyIslandClient_Data\` assets:
  - `resources.assets` 738 MB, `resources.assets.resS` **2.91 GB**,
    `resources.resource` 135 MB, `sharedassets0.assets.resS` 237 MB
  - `StreamingAssets\aa\` — Unity Addressables bundles (local catalog)
- Launcher lives separately at `C:\Program Files (x86)\Nifty Island\`.

## What was copied into this workspace (`01_client_backup/`)
- `NiftyIslandClient.exe`
- `Managed/` — all 368 DLLs (the game logic)
- `boot.config`, `app.info`, `Version.txt`, `v.txt`
- `ScriptingAssemblies.json`, `RuntimeInitializeOnLoads.json`
- `UnityServicesProjectConfiguration.json` (Vivox config)
- `aa_catalog.json`, `aa_settings.json` (addressables)
- `SHA256-MANIFEST.txt` — SHA256 of **all 702 files** of the full on-disk
  install (including the multi-GB asset blobs that were not duplicated).

**Not copied (hashed only):** the large asset blobs (`*.assets`, `*.resS`,
`resources.resource`, addressables `.bundle` files). They are safe in place; to
complete Phase 5, copy the whole `application/` folder to archival storage and
verify against `SHA256-MANIFEST.txt`.

## Integrity
- `Assembly-CSharp.dll` SHA256:
  `595b3757ab4b734b91960edd3c35bba8dc54443d40d695254669a9ac8cc3a51f`
- Full manifest: `01_client_backup/SHA256-MANIFEST.txt` (702 entries).

## Reproduce verification later
```powershell
# from the live install dir, compare current files to the recorded manifest
Get-FileHash -Algorithm SHA256 <file>   # compare against SHA256-MANIFEST.txt
```
