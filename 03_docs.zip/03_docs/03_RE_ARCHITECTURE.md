# Client Architecture — Reverse-Engineering Notes

Build: v2.15.04, Unity Mono. 368 managed DLLs. Decompiled with `ilspycmd` into
`02_decompiled_src/`.

## Big picture
The client is a **modular, DI-driven** application. Entry is a tiny
`Assembly-CSharp` bootstrap; real logic lives in `NiftyIsland.*` assemblies
resolved through a TinyIoC container (`App.ApplicationImpl`,
`NiftyIsland.AppDef`). Layers are clearly split:

- `*.Common`  — shared data models / schemas (client + server both use these)
- `*.Client`  — client-side behaviour
- `*.Server`  — a few server-side bits shipped in the client
  (`NiftyIsland.Application.Infrastructure.Server`) — worth reading, they hint at
  server expectations.
- `Presentation.*` — Unity rendering/UI, not needed for a server.

## Networking stack
- **REST:** `IWebRequestClient` (in `NiftyIsland.AppDef`) + `NiftyIsland.WebRequests`.
  Plain `System.Net.WebRequest`, JSON bodies, `Bearer` auth, retry w/ backoff
  (`Polly.dll` also present). Errors logged with endpoint+method+status.
- **Realtime:** `NiftyIsland.Transport.Common` / `.Client` uses **LiteNetLib
  (reliable UDP)** — the open-source lib is vendored under
  `NiftyIsland.Transport.Common/LiteNetLib/`. Application messages sit on top as
  **CommandSchema** objects (serialized commands). This is the protocol a
  replacement game server must speak — and because the transport is stock
  LiteNetLib, a server can link the same library and only needs to reproduce the
  command/packet serialization. (`websocket-sharp` is also present but for a
  separate channel, not game-state.)
- **Multiplayer session brokering:** MatchMaker API Gateway → AWS GameLift
  (`AmazonGameLiftSDKPlugin.Runtime`). See `02_BACKEND_MAP.md`.

## Key assemblies to read next (server-relevant)
| Assembly | Why |
|----------|-----|
| `NiftyIsland.Transport.Common` | wire protocol, framing, connection lifecycle |
| `NiftyIsland.GameInterface.Common` (164 KB) | the command/message contracts |
| `NiftyIsland.Application.User.Common` | auth/session data shapes |
| `NiftyIsland.Application.Infrastructure.Common` + `.Server` | request/response DTOs, save model |
| `NiftyIsland.Application.Infrastructure.Common.SaveData` | how worlds/state persist |
| `NiftyIsland.Island.Common` + `NiftyIsland.PlayerState` | world & player state |
| `NiftyIsland.Bootstrap.Client.Unity` | dev connection UI: shows how the client can be pointed at an arbitrary fleet/host (a manual-connect hook we can exploit for localhost testing) |
| `NiftyIsland.PerformanceTesting.Bots` | dev-written headless client — documents the connect flow (IP+port OR matchmaker+islandId) and is a near-complete reference client implementation |

> `PerformanceTesting.Bots` is the single most useful artifact: Nifty's own
> engineers wrote a minimal client there. It shows exactly how to authenticate,
> ask the matchmaker for an island, and drive an avatar. Read it before writing
> any server code.

## Auth model (from `IWebRequestClient`)
1. Client obtains a bearer token (login/handshake — capture needed for exact flow).
2. Token set via `SetAuthToken(string)`; sent as `Authorization: Bearer <token>`.
3. Server may return a refreshed token in a response header (cookie-style
   `name=value; ...`), re-parsed automatically.
→ A replacement auth service just needs to return a token string the client
   stores, then accept that token on subsequent calls (validation can be
   permissive for a private community server).

## Config kill-switches (easy early wins for a stub server)
- `flags.niftyisland.com` — ConfigCat proxy; serve static flag JSON.
- `downloads.niftyisland.com/game-status/game-status.txt` — return an "ok" value.
- `downloads.niftyisland.com/wager-status/wager-status.txt` — same.
Redirect these (hosts file / proxy) to a local server that returns benign values.

## What is NOT needed for a server
Everything under `NiftyIsland.Presentation.*`, `VRM*`, `UniGLTF`, `FinalIK`,
`Rewired`, `SkiaSharp`, `Astar`, rendering/animation/input — client-only.
