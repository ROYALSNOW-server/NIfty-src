# Nifty Island — Preservation Project

Goal: preserve the last working Nifty Island client and eventually stand up a
community-run backend after the official servers shut down.

Client under study: **v2.15.04** (build-guid `1987477470c64283bd4cf94a50134dbf`),
Unity **Mono** build (not IL2CPP — the C# game logic decompiles cleanly).

## Workspace layout

```
nifty new/
├── 01_client_backup/      Untouched copy of the client logic + config (DO NOT EDIT)
│   ├── NiftyIslandClient.exe
│   ├── Managed/            All 368 managed DLLs
│   ├── *.json, boot.config, app.info, Version.txt
│   └── SHA256-MANIFEST.txt Hashes of the FULL on-disk install (incl. 4.8GB assets)
├── 02_decompiled_src/      C# decompiled from every NiftyIsland.* assembly (ILSpy)
├── 03_docs/                This documentation
├── 04_server/              (future) replacement backend
└── 05_research_notes/      Scratch / findings-in-progress
```

The live install still sits at
`C:\Users\Gunna\AppData\Roaming\Nifty Island\application` — untouched. The 2.9 GB
asset blobs (`resources.assets.resS` etc.) were **not** copied here yet; they are
hashed in the manifest and can be archived later with a plain file copy.

## Progress against the 10-phase plan

| Phase | Description | Status |
|-------|-------------|--------|
| 1 | Preserve original client | ✅ logic+config backed up, full install hashed |
| 2 | Reverse-engineering environment | ✅ Mono confirmed, all assemblies decompiled |
| 3 | Map the backend | ✅ first pass done — see `02_BACKEND_MAP.md` |
| 4 | Determine what works offline | 🟠 capture harness ready in `06_capture/` — **RUN BEFORE FRIDAY (servers go down 2026-08-14)** |
| 5 | Preserve assets | 🟡 assets safe on disk + hashed; not yet archived |
| 6 | Design replacement backend | ✅ realtime wire protocol documented (`04_WIRE_PROTOCOL.md`) + 988-message catalogue (`05_research_notes/message_catalogue.md`) |
| 7 | Local test server | 🟡 working, extensible base in `04_server/NiftyServer` (transport+framing+router proven; join handshake pending capture) |
| 8 | Replace services one by one | ⬜ handler-per-message architecture in place; fill in from capture |
| 9 | Community server | ⬜ |
| 10 | Preservation release | ⬜ |

## Immediate next steps
1. 🔴 **RUN THE CAPTURE BEFORE FRIDAY** — official servers go down 2026-08-14.
   Follow `06_capture/README.md`: `capture-udp.ps1` (required — recovers the join
   handshake from unencrypted UDP) and optionally `capture-https.ps1`
   (login/matchmaker). This is the one irreplaceable, time-boxed task.
2. Give the capture files to Claude → it decodes them with the 988-message
   catalogue and fills the `TODO(handshake)` points in `04_server`.
3. Add a handler per message the handshake needs (copy `GameSessionCommandHandler`),
   until the retail client loads into a local island.
