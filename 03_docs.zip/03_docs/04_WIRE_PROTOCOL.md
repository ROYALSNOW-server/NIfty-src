# Nifty Island — Realtime Wire Protocol (v2.15.04)

Reconstructed from the decompiled `NiftyIsland.Transport.Common` / `.Client`,
`NiftyIsland.GameInterface.Common`, and the dev reference client
`NiftyIsland.PerformanceTesting.Bots`. Everything here is derived from client
code; items marked **[capture]** need a live packet/HTTP capture to confirm exact
bytes/paths.

This is enough to start implementing a compatible game server.

---

## 0. Layer cake

```
Game logic  : GameState replication + ClientRpc + *Command messages
Message layer: ISmallBuffer messages, dispatched by 16-bit MessageId
Framing     : ByteBuffer (little-endian, offset-addressed, quantization)
Transport   : LiteNetLib (reliable UDP), 3 channels
Session setup: REST auth + matchmaker (HTTP) → host:port to connect to
```

The realtime path is **UDP via LiteNetLib** — *not* websockets. `websocket-sharp`
in the client is a separate channel (signaling/voice), not game state.

---

## 1. Session establishment

### 1a. Two ways to reach a game server (from `BotBootstrap` / `ConnectionConfig`)
- **Direct IP:** host + port → connect straight to a game-server instance.
  Reference-client flags: `-h <host> -p <port>`.
- **Matchmaker:** island id + backend API url → backend returns a server
  host:port, then connect. Flags: `-i <islandId> -d <backendApiUrl>`.

Default game-server port: **`3500`** (`ConnectionConfigCommandLineParser.Port`).
`ConnectionConfig` is literally just `{ string host; int port; }`.

### 1b. Auth (from `BotAppConfig` / `BotUserInfo` + `IWebRequestClient`)
- Account auth is **username + password** → a **bearer token**. The bots log in as
  `bot{id}@niftyisland.io` / `Password1!`.
- Token is then sent as `Authorization: Bearer <token>` on REST calls; the server
  may return a refreshed token in a response header (cookie-style `name=value;…`),
  re-parsed by `SetAuthToken(HttpWebResponse)`.
- REST base = the "backend api url" (`ApiSpec.url`, the `-d` arg). Prod:
  `api.niftyisland.com`. **[capture]** exact login path + request/response JSON.

### 1c. Matchmaker
- Prod matchmaker: `https://9ia2gjqr5l.execute-api.us-east-2.amazonaws.com/MatchMaker`
  (AWS API Gateway) → AWS GameLift fleet → returns a game-server host:port.
  **[capture]** request (islandId + auth) and response (host/port/session token).
- Direct-IP mode bypasses all of this — the fastest path for a local server.

### 1d. LiteNetLib connect
- Client calls `netManager.Connect(host, port)`. The server accepts the connection
  request (reference server-side stub `NetworkStreamWriterImpl` calls
  `request.Accept()` unconditionally). **[capture]** whether a connize key / connect
  payload is required by the real GameLift server; the local transport uses none.

---

## 2. Transport: LiteNetLib channels

`NetPeerConnectionImpl` maps the three logical send types to **channels** and
**delivery methods**:

| Logical send | Channel byte | LiteNetLib DeliveryMethod | Use |
|--------------|:---:|---------------------------|-----|
| `SendState`  | **0** | `Unreliable` | high-frequency state (movement, transforms) |
| `SendEvent`  | **0** | `Unreliable` | fire-and-forget events |
| `SendCommand`| **1** | `ReliableOrdered` | commands that must arrive in order |
| `SendAdminCommand` | **2** | `ReliableOrdered` | internal/admin only (restricted) |

- Channel **2 is reserved** — sending State/Command on channel 2 throws
  `RestrictedChannelException`.
- `SendState(msg, channel)` / `SendCommand(msg, channel)` allow custom channels
  (except 2) for sub-streams.
- Payload put on the wire is the message's raw `ByteBuffer` bytes:
  `peer.Send(message.ByteBuffer, channel, deliveryMethod)`. No extra Nifty header
  is added beyond what's already in the ByteBuffer (see §3).
- LiteNetLib itself is stock — its own packet header (connection, channel, seq,
  fragmentation) applies underneath. A server should **link the same LiteNetLib**
  rather than reimplement it. (Vendored under
  `NiftyIsland.Transport.Common/LiteNetLib/`.)

---

## 3. Framing: the `ByteBuffer` format

All multi-byte integers are **little-endian** (`WriteLittleEndian`/`ReadLittleEndian`).
`ByteBuffer` is **offset-addressed** — each field is written/read at an explicit
byte offset (not a streaming cursor), so message layouts are fixed structs.

### Message envelope
Every `ISmallBuffer` message begins with its type id:

```
offset 0 : ushort MessageId      (LE)   ← identifies the message type
offset 2 : <type-specific fields at fixed offsets>
```

Dispatch = read `GetUshort(0)` and match against each type's `MessageId`
(`BufferHasIdentifier` does exactly `buffer.GetUshort(0) == MessageId`).

### MessageId derivation (must match on the server)
`MessageId = StableHash16(typeName)` where:

```csharp
// FNV-32 over the string's UTF-16 code units, folded to 16 bits
uint h = 2166136261;
foreach (char c in typeName) { h *= 16777619; h ^= c; }
ushort id = (ushort)((h >> 16) ^ h);
```

`typeName` is the short type name (e.g. `"GameSessionCommand"`). At startup the
client scans all assemblies for `ISmallBuffer` types and, on hash **collision**,
remaps the loser to `StableHash16(typeName + n)` for increasing `n`
(`SmallBuffersMessageIds.RemapCollidingMessageIds`). A server must reproduce the
same discovery order to stay in sync, or (simpler) negotiate/normalize ids.

### Primitive encodings
- **Integers:** `byte/sbyte`(1), `short/ushort`(2), `int/uint`(4), `long/ulong`(8),
  little-endian.
- **float** 4 bytes (IEEE-754), **double** 8 bytes, **bool** 1 byte, bit-addressable
  via `GetBool(index, bit)`.
- **string (UTF-8):** written as raw UTF-8 bytes at an offset; length is carried
  separately as a **`ushort` length prefix**, with **`0xFFFF` (65535) = null**.
  Pattern (from `GameSessionCommand`):
  ```
  ushort len = (value==null) ? 0xFFFF : utf8ByteCount(value);
  PutUshort(lenOffset, len);
  if (value != null) PutStringUTF8(dataOffset, value);
  ```
  Read back with `GetObjectLength(lenOffset)` (returns 0 for the 0xFFFF sentinel)
  then `GetStringUTF8(dataOffset, len)`.
- **Unity types:** `Vector2/3/4`, `Vector2Int/Vector3Int`, `Quaternion`, `Color32`,
  `Bounds`, `Rect`, and array variants (`PutVector3Array`, …).

### Quantization (bandwidth compression)
Used heavily on the Unreliable state channel:
- **`PutQuantizedFloat(offset, value, min, max)`**: range `max-min ≤ 360` → 2 bytes
  (0..65535), else 3 bytes (0..16777215). Encoded as
  `round((value-min)/(max-min) * scale)`, little-endian. Returns bytes written.
- **`PutQuantizedVector2/3/4`**: per-component quantized floats with per-axis min/max.
- **`PutQuantizedQuaternion`**: components quantized to 10-bit (`MaxQuantizeIntQuaternion = 1023`).
- Higher-level wrappers in `GameInterface.Common/GameState`: `CompressedFloat`,
  `CompressedVector2/3/4`, `CompressedQuaternion`.

### Buffers are pooled
`ByteBufferPool` recycles buffers (`Get`/`Release`, sub-buffers, delayed-release
while a packet is in-flight). Irrelevant to the wire format, but explains
`Dispose()`/`Release()` calls on messages — a server can ignore pooling and just
alloc.

---

## 4. Message categories & higher-level systems

- **`*Command` (ISmallBuffer)** — discrete reliable actions on channel 1. Example
  contract: `GameSessionCommand { string Id }` (session/join identifier). Command
  *schemas* (`GameSessionCommandSchema : CommandSchema`) describe fields via
  `[GameState]` attributes and codegen.
- **State replication** — `GameState`, `GameStateObject`, `GameStateProperty`,
  `GameStateObjectReplicator`, `GameStateObjectInterpolator`. A networked
  object/property graph replicated (largely) over the Unreliable channel, with
  client-side interpolation. `[GameState]` marks replicated members;
  `Compressed*`/`*Equivalence` types define how each is serialized and when it's
  considered "changed".
- **RPC** — methods tagged `[ClientRpc]` are invoked remotely (server→client).
- **`EmbeddedMessage`** — messages can nest sub-buffers (see `subBuffers` in
  `ByteBuffer`), i.e. a message can contain a length-prefixed inner message.
- **Session/sim config** — `GameSimulationConfig`: `tickRateMs`,
  `messageSendRateMs`, `maxPlayers = 20` (default), `persistenceEnabled`,
  `clientTickOffset`. Confirms a **small-instance, tick-based authoritative
  server** (~20 players per island instance).

---

## 5. Worked example — `GameSessionCommand`

C# (from source) → bytes:

```
Create(Id="abc"):
  MessageId = StableHash16("GameSessionCommand")   // ushort, LE @0
  len       = 3                                     // ushort, LE @2  (utf8 count)
  "abc"     = 61 62 63                              // @4..7

Wire (LE): [ID_lo ID_hi] [03 00] [61 62 63]
Null Id: len field = FF FF, no string bytes.
```

Server receive: `GetUshort(0)` → match `GameSessionCommand.MessageId`;
`GetObjectLength(2)` → 3; `GetStringUTF8(4,3)` → `"abc"`.

---

## 6. Still to confirm with a live capture (Phase 4)
1. **Login**: exact endpoint + request/response JSON on `api.niftyisland.com`
   (how username/password → bearer token; refresh header format).
2. **Matchmaker**: request shape (islandId, auth, region) and response
   (host, port, any per-session token) from the `/MatchMaker` gateway.
3. **LiteNetLib connect**: whether the real server requires a connect key/payload
   (local transport accepts unconditionally).
4. **The initial handshake message sequence** once connected (which `*Command` /
   GameState snapshot the server sends first, and what the client must send to be
   admitted — e.g. a join/auth command carrying the session token).
5. Full **message catalogue**: enumerate all `ISmallBuffer` types and their
   `[GameState]` field layouts (can be generated statically — see §7).

---

## 7. Building a compatible server — recommended path
1. **Reuse LiteNetLib** (same vendored version) for transport; open UDP on 3500,
   accept connections, honour channels 0/1/2 + delivery methods in §2.
2. **Port `ByteBuffer`** read/write (or re-implement the encodings in §3) so you
   can parse/emit messages byte-for-byte, including the `StableHash16` ids.
3. **Auto-generate the message catalogue**: reflect over the decompiled
   `ISmallBuffer` types (there are Deserialize/Create pairs like
   `GameSessionCommand`) to dump every id + field offset. This gives the full
   protocol table without a capture.
4. **Stand up the minimum session**: accept a connection, send the initial
   GameState snapshot for one island, echo movement (State ch.0), ack Commands
   (ch.1). Point the client via **direct IP** (`host`/`port` override) to skip
   the matchmaker while iterating locally.
5. Layer on persistence, inventory, social, etc. later (those are REST, see
   `02_BACKEND_MAP.md`).

> Best first milestone: client connects to a localhost LiteNetLib server, receives
> a world snapshot, and an avatar moves. Everything else builds on that loop.
```
