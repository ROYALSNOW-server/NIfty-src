# Join Handshake — decoded from live capture (2026-08-12)

Source: `06_capture/nifty-udp-session.pcapng` — a real session captured against the
live servers before shutdown. Game server was AWS GameLift `18.225.8.96` (us-east-2),
LiteNetLib UDP, dynamic ports (7783, 7786 seen for two islands).
Decoder: `06_capture/decode.ps1` → `06_capture/join-timeline.txt`.

## Confirmed transport facts
- **ProtocolId = 11** on the wire (matches our server). Connect sequence:
  `ConnectRequest(proto=11)` → `ConnectAccept` → `Ping/Pong` → `MtuCheck/MtuOk`
  → `Channeled` game data.
- **Channeled (reliable) packet header = 4 bytes** (property + seq(2) + channel),
  then the ByteBuffer begins (MessageId at that +4 offset). Large messages are
  fragmented across packets; ~157/458 channeled packets are message-heads, the
  rest are fragments/merged.

## The join sequence (server's opening moves)
When the client connects to an island, the server **streams the entire world
state**, then terrain, then the client signals ready:

1. **Server → Client: world objects** — a burst of `CreateGameStateObjectCommand`
   (76 seen), one per world object (avatars, props, land pieces, plugins…), plus
   `UpdateGameStateObjectCommand` for initial property values.
2. **Client → Server: terrain pull** — the client fires `ChunkDataRequestCommand`
   repeatedly (70 seen) to request terrain/land chunks; the server replies with
   `ChunkDataResponseCommand`.
3. **Client → Server: `ClientLandInitializedCommand`** — the client announces the
   land finished loading (the "I'm in" signal).
4. **Ongoing:** `UpdateGameStateObjectCommand` both ways (state sync, e.g. avatar
   transform as you move), `RpcCommand` for discrete actions,
   `ResumeSequenceNoPayloadCommand` for flow control.

## Message roles (from this capture)
| Message | Dir | Role |
|---------|-----|------|
| `CreateGameStateObjectCommand` | S→C | instantiate a networked object (the world snapshot) |
| `UpdateGameStateObjectCommand` | both | replicate property changes (movement, state) |
| `ChunkDataRequestCommand` | C→S | client asks for a terrain/land chunk |
| `ChunkDataResponseCommand` | S→C | server sends chunk data |
| `ClientLandInitializedCommand` | C→S | client finished loading the land |
| `RpcCommand` | both | remote procedure call (discrete actions) |
| `ResumeSequenceNoPayloadCommand` | both | reliable-stream flow control |

## What this means for the server
The minimum "client loads into an empty island" path is now known:
1. Accept the LiteNetLib connection (done).
2. On connect, send a small set of `CreateGameStateObjectCommand` (at least the
   land + the player's avatar), then be ready to answer `ChunkDataRequestCommand`
   with `ChunkDataResponseCommand`.
3. Accept `ClientLandInitializedCommand` and mark the player in-world.
4. Echo/broadcast `UpdateGameStateObjectCommand` for movement.

## Still to decode (next passes over the same capture)
- **Field layouts** of `CreateGameStateObjectCommand` / `UpdateGameStateObjectCommand`
  (the GameStateObject serialization — object id, type, transform, properties).
  Needs LiteNetLib **fragment reassembly** (large creates span packets).
- **`ChunkData*`** payload format (terrain representation).
- Whether an **auth/session token** is required before the world stream (none was
  seen pre-stream in this capture — the GameLift session may authorize at the
  matchmaker/HTTPS layer, so a private direct-IP server can likely skip it).
- The **very first** app message(s) right after connect (confirm nothing gates the
  stream).

> The handshake message *sequence* is solved. Remaining work is decoding the
> *bodies* of a handful of message types — all reproducible offline from this
> capture now that the servers are down.
